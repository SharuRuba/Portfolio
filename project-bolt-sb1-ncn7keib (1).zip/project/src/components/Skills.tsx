import React from 'react';

interface Skill {
  category: string;
  skills: {
    name: string;
    level: number;
  }[];
}

const Skills: React.FC = () => {
  const skillsData: Skill[] = [
    {
      category: "Programming Languages",
      skills: [
        { name: "JavaScript", level: 90 },
        { name: "TypeScript", level: 85 },
        { name: "Java", level: 80 },
        { name: "Python", level: 75 },
        { name: "Kotlin", level: 70 },
      ]
    },
    {
      category: "Frontend Development",
      skills: [
        { name: "React Native", level: 90 },
        { name: "Flutter", level: 85 },
        { name: "React", level: 80 },
        { name: "HTML/CSS", level: 85 },
      ]
    },
    {
      category: "Backend & Database",
      skills: [
        { name: "Node.js", level: 85 },
        { name: "Express", level: 80 },
        { name: "Firebase", level: 85 },
        { name: "Supabase", level: 75 },
        { name: "MongoDB", level: 70 },
      ]
    },
    {
      category: "Tools & Technologies",
      skills: [
        { name: "Git/GitHub", level: 90 },
        { name: "Azure Cloud", level: 75 },
        { name: "Google Cloud", level: 70 },
        { name: "IoT", level: 80 },
        { name: "REST APIs", level: 85 },
      ]
    }
  ];

  return (
    <section id="skills" className="py-20 bg-white">
      <div className="max-w-6xl mx-auto px-4">
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-16 relative">
          <span className="bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-teal-500">
            My Skills
          </span>
          <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-24 h-1 bg-blue-500 rounded-full"></div>
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
          {skillsData.map((skillCategory, categoryIndex) => (
            <div key={categoryIndex} className="bg-gray-50 p-6 rounded-xl shadow-md">
              <h3 className="text-xl font-bold text-gray-800 mb-6 pb-2 border-b-2 border-blue-200">
                {skillCategory.category}
              </h3>
              <div className="space-y-5">
                {skillCategory.skills.map((skill, skillIndex) => (
                  <div key={skillIndex}>
                    <div className="flex justify-between mb-1">
                      <span className="text-gray-700 font-medium">{skill.name}</span>
                      <span className="text-gray-500 text-sm">{skill.level}%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2.5">
                      <div 
                        className="h-2.5 rounded-full" 
                        style={{
                          width: `${skill.level}%`,
                          background: `linear-gradient(to right, #3B82F6 ${skill.level}%, #0D9488)`
                        }}
                      ></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Skills;