import React from 'react';
import { Award, Check } from 'lucide-react';

interface Certification {
  title: string;
  issuer: string;
  description: string;
  icon: 'award' | 'check';
}

const Certifications: React.FC = () => {
  const certifications: Certification[] = [
    {
      title: "Azure Fundamentals",
      issuer: "Microsoft",
      description: "Validated understanding of cloud concepts and Microsoft Azure services, workloads, security, privacy, pricing, and support.",
      icon: 'award'
    },
    {
      title: "Enhancing Soft Skills and Personality Development",
      issuer: "NPTEL",
      description: "Silver badge for completing coursework in communication skills, personal effectiveness, and professional development.",
      icon: 'check'
    },
    {
      title: "Introduction to Internet of Things",
      issuer: "NPTEL",
      description: "Silver badge for mastering IoT foundations, covering sensors, networks, data analytics, and real-world applications.",
      icon: 'check'
    }
  ];

  return (
    <section id="certifications" className="py-20 bg-gray-50">
      <div className="max-w-6xl mx-auto px-4">
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-16 relative">
          <span className="bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-teal-500">
            Certifications
          </span>
          <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-24 h-1 bg-blue-500 rounded-full"></div>
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {certifications.map((cert, index) => (
            <div 
              key={index} 
              className="bg-white p-6 rounded-xl shadow-md transform transition-all duration-300 hover:shadow-xl hover:-translate-y-2"
            >
              <div className="flex justify-center mb-4">
                <div className="w-16 h-16 rounded-full bg-blue-100 flex items-center justify-center text-blue-600">
                  {cert.icon === 'award' ? <Award size={32} /> : <Check size={32} />}
                </div>
              </div>
              <h3 className="text-xl font-bold text-center text-gray-800 mb-2">{cert.title}</h3>
              <p className="text-center text-blue-600 font-medium mb-4">{cert.issuer}</p>
              <p className="text-gray-600 text-center">{cert.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Certifications;