import React, { useState, useEffect } from 'react';
import { Menu, X, Moon, Sun } from 'lucide-react';

interface HeaderProps {
  toggleTheme: () => void;
  isDarkMode: boolean;
}

const Header: React.FC<HeaderProps> = ({ toggleTheme, isDarkMode }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  return (
    <header 
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled 
          ? 'bg-white shadow-md py-3 dark:bg-gray-900' 
          : 'bg-transparent py-5'
      }`}
    >
      <div className="max-w-6xl mx-auto px-4">
        <div className="flex items-center justify-between">
          <a href="#" className={`text-xl font-bold ${isScrolled ? 'text-blue-600 dark:text-white' : 'text-white'}`}>
            SR
          </a>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <a 
              href="#about" 
              className={`font-medium transition-colors ${
                isScrolled ? 'text-gray-800 hover:text-blue-600 dark:text-gray-300 dark:hover:text-white' : 'text-gray-200 hover:text-white'
              }`}
            >
              About
            </a>
            <a 
              href="#projects" 
              className={`font-medium transition-colors ${
                isScrolled ? 'text-gray-800 hover:text-blue-600 dark:text-gray-300 dark:hover:text-white' : 'text-gray-200 hover:text-white'
              }`}
            >
              Projects
            </a>
            <a 
              href="#skills" 
              className={`font-medium transition-colors ${
                isScrolled ? 'text-gray-800 hover:text-blue-600 dark:text-gray-300 dark:hover:text-white' : 'text-gray-200 hover:text-white'
              }`}
            >
              Skills
            </a>
            <a 
              href="#certifications" 
              className={`font-medium transition-colors ${
                isScrolled ? 'text-gray-800 hover:text-blue-600 dark:text-gray-300 dark:hover:text-white' : 'text-gray-200 hover:text-white'
              }`}
            >
              Certifications
            </a>
            <a 
              href="#contact" 
              className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg transition-colors"
            >
              Contact
            </a>
            <button 
              onClick={toggleTheme} 
              className={`p-2 rounded-full ${
                isScrolled ? 'text-gray-800 hover:bg-gray-100 dark:text-white dark:hover:bg-gray-800' : 'text-white hover:bg-white/20'
              }`}
              aria-label="Toggle theme"
            >
              {isDarkMode ? <Sun size={20} /> : <Moon size={20} />}
            </button>
          </nav>

          {/* Mobile Menu Button */}
          <div className="md:hidden flex items-center">
            <button 
              onClick={toggleTheme} 
              className={`p-2 rounded-full mr-2 ${
                isScrolled ? 'text-gray-800 dark:text-white' : 'text-white'
              }`}
              aria-label="Toggle theme"
            >
              {isDarkMode ? <Sun size={20} /> : <Moon size={20} />}
            </button>
            <button 
              onClick={toggleMenu}
              className={`p-2 ${isScrolled ? 'text-gray-800 dark:text-white' : 'text-white'}`}
              aria-label="Toggle menu"
            >
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Navigation Menu */}
      {isMenuOpen && (
        <div className="md:hidden bg-white dark:bg-gray-900 shadow-lg absolute top-full left-0 right-0">
          <nav className="flex flex-col py-4">
            <a 
              href="#about" 
              className="px-4 py-3 text-gray-800 dark:text-white hover:bg-gray-100 dark:hover:bg-gray-800"
              onClick={toggleMenu}
            >
              About
            </a>
            <a 
              href="#projects" 
              className="px-4 py-3 text-gray-800 dark:text-white hover:bg-gray-100 dark:hover:bg-gray-800"
              onClick={toggleMenu}
            >
              Projects
            </a>
            <a 
              href="#skills" 
              className="px-4 py-3 text-gray-800 dark:text-white hover:bg-gray-100 dark:hover:bg-gray-800"
              onClick={toggleMenu}
            >
              Skills
            </a>
            <a 
              href="#certifications" 
              className="px-4 py-3 text-gray-800 dark:text-white hover:bg-gray-100 dark:hover:bg-gray-800"
              onClick={toggleMenu}
            >
              Certifications
            </a>
            <a 
              href="#contact" 
              className="mx-4 my-3 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg text-center"
              onClick={toggleMenu}
            >
              Contact
            </a>
          </nav>
        </div>
      )}
    </header>
  );
};

export default Header;