import React from 'react';
import { Github as GitHub, Linkedin, Mail, ChevronDown } from 'lucide-react';

const Hero: React.FC = () => {
  const scrollToProjects = () => {
    const projectsSection = document.getElementById('projects');
    if (projectsSection) {
      projectsSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="relative min-h-screen flex items-center justify-center bg-gradient-to-br from-gray-900 to-gray-800 text-white p-4">
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-full">
          {/* Animated background elements */}
          <div className="absolute top-20 left-10 w-64 h-64 bg-blue-500 rounded-full mix-blend-multiply filter blur-3xl opacity-10 animate-blob"></div>
          <div className="absolute top-40 right-10 w-72 h-72 bg-teal-500 rounded-full mix-blend-multiply filter blur-3xl opacity-10 animate-blob animation-delay-2000"></div>
          <div className="absolute bottom-20 left-1/3 w-80 h-80 bg-orange-500 rounded-full mix-blend-multiply filter blur-3xl opacity-10 animate-blob animation-delay-4000"></div>
        </div>
      </div>

      <div className="max-w-5xl mx-auto text-center relative z-10">
        <h1 className="text-4xl md:text-6xl font-bold mb-4 animate-fadeIn">
          SHARU RUBA S
        </h1>
        <h2 className="text-xl md:text-2xl font-medium text-blue-400 mb-6 animate-fadeInUp animation-delay-300">
          Software Developer
        </h2>
        <p className="text-lg md:text-xl text-gray-300 max-w-2xl mx-auto mb-8 animate-fadeInUp animation-delay-600">
          Specializing in Mobile Development and Web Development, Full Stack Technologies, Cloud Services, and IoT projects
        </p>
        
        <div className="flex justify-center space-x-4 mb-12 animate-fadeInUp animation-delay-900">
          <a
            href="https://github.com/SharuRuba"
            target="_blank"
            rel="noopener noreferrer"
            className="text-gray-300 hover:text-white transition-colors p-2 hover:bg-gray-700 rounded-full"
            aria-label="GitHub"
          >
            <GitHub size={24} />
          </a>
          <a
            href="https://www.linkedin.com/in/sharu-ruba-s-5699a4257"
            target="_blank"
            rel="noopener noreferrer"
            className="text-gray-300 hover:text-white transition-colors p-2 hover:bg-gray-700 rounded-full"
            aria-label="LinkedIn"
          >
            <Linkedin size={24} />
          </a>
          <a
            href="mailto:sharuruba13@gmail.com"
            className="text-gray-300 hover:text-white transition-colors p-2 hover:bg-gray-700 rounded-full"
            aria-label="Email"
          >
            <Mail size={24} />
          </a>
        </div>
        
        <button
          onClick={scrollToProjects}
          className="flex items-center justify-center mx-auto py-3 px-6 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg transition-all transform hover:scale-105 animate-fadeInUp animation-delay-1200"
        >
          View My Work
          <ChevronDown size={20} className="ml-2 animate-bounce" />
        </button>
      </div>
    </section>
  );
};

export default Hero;