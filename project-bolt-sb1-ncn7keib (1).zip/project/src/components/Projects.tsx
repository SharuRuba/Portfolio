import React, { useState } from 'react';
import { ExternalLink, Github } from 'lucide-react';

interface Project {
  id: number;
  title: string;
  description: string;
  tech: string[];
  githubLink: string;
  image: string;
}

const Projects: React.FC = () => {
  const projects: Project[] = [
    {
      id: 1,
      title: "Growing Agro - Smart Farming Mobile Application",
      description: "A mobile solution empowering farmers with features like plant disease detection, soil analysis, weather forecasting, and expert consultation.",
      tech: ["React Native", "Expo", "TypeScript", "Supabase", "Weather API"],
      githubLink: "https://github.com/SharuRuba/growing-agro.git",
      image: "https://images.pexels.com/photos/2132250/pexels-photo-2132250.jpeg"
    },
    {
      id: 2,
      title: "Prediction of Toxic Level in Lavatory and Alert System",
      description: "An IoT-based Android app that monitors toxic gas levels in public lavatories and provides real-time alerts for cleanliness and safety.",
      tech: ["Android", "Java/Kotlin", "IoT Sensors", "Firebase", "Realtime Database"],
      githubLink: "https://github.com/SharuRuba/Prediction-of-toxic-level-in-lavatory-and-alret-generating-system-using-android-applications-.git",
      image: "https://images.pexels.com/photos/2582937/pexels-photo-2582937.jpeg"
    },
    {
      id: 3,
      title: "Sign Language Recognition System",
      description: "A mobile application that recognizes sign language gestures using image processing and converts them to text, assisting communication for the hearing and speech impaired.",
      tech: ["React Native", "Expo", "TypeScript", "Camera API"],
      githubLink: "https://github.com/SharuRuba/Sign-language-.git",
      image: "https://images.pexels.com/photos/33999/pexels-photo.jpg"
    },
    {
      id: 4,
      title: "Calories Tracker and Food Recognition App",
      description: "An app for tracking calorie intake by recognizing food items through image analysis, with personalized dietary suggestions.",
      tech: ["React Native", "Expo", "TypeScript", "Camera API"],
      githubLink: "https://github.com/SharuRuba/CaloriesTracker.git",
      image: "https://images.pexels.com/photos/46173/diet-calorie-calculator-counting-46173.jpeg"
    },
    {
      id: 5,
      title: "AI Meme Generator",
      description: "An app that generates memes by combining trending images with humorous captions, leveraging text generation APIs.",
      tech: ["Python", "Flask", "OpenAI API", "HTML", "CSS", "JavaScript"],
      githubLink: "https://github.com/SharuRuba/AI-Meme-Generator.git",
      image: "https://images.pexels.com/photos/1011329/pexels-photo-1011329.jpeg"
    }
  ];

  const [activeProject, setActiveProject] = useState<Project | null>(null);

  const openProjectDetails = (project: Project) => {
    setActiveProject(project);
  };

  const closeProjectDetails = () => {
    setActiveProject(null);
  };

  return (
    <section id="projects" className="py-20 bg-gray-50">
      <div className="max-w-6xl mx-auto px-4">
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-16 relative">
          <span className="bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-teal-500">
            My Projects
          </span>
          <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-24 h-1 bg-blue-500 rounded-full"></div>
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project) => (
            <div
              key={project.id}
              className="bg-white rounded-xl overflow-hidden shadow-lg transform transition-all duration-300 hover:shadow-xl hover:-translate-y-2"
            >
              <div className="h-48 overflow-hidden">
                <img
                  src={project.image}
                  alt={project.title}
                  className="w-full h-full object-cover transition-transform duration-500 hover:scale-110"
                />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold text-gray-800 mb-3 line-clamp-2">{project.title}</h3>
                <p className="text-gray-600 mb-4 line-clamp-3">{project.description}</p>
                <div className="flex flex-wrap gap-2 mb-4">
                  {project.tech.slice(0, 3).map((tech, index) => (
                    <span key={index} className="px-2 py-1 text-xs font-medium bg-blue-100 text-blue-700 rounded-full">
                      {tech}
                    </span>
                  ))}
                  {project.tech.length > 3 && (
                    <span className="px-2 py-1 text-xs font-medium bg-gray-100 text-gray-700 rounded-full">
                      +{project.tech.length - 3} more
                    </span>
                  )}
                </div>
                <div className="flex justify-between mt-auto">
                  <button
                    onClick={() => openProjectDetails(project)}
                    className="text-blue-600 hover:text-blue-800 font-medium flex items-center"
                  >
                    View Details
                    <ExternalLink size={16} className="ml-1" />
                  </button>
                  <a
                    href={project.githubLink}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-gray-700 hover:text-gray-900 flex items-center"
                    aria-label="GitHub Repository"
                  >
                    <Github size={20} />
                  </a>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Project Details Modal */}
      {activeProject && (
        <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg w-full max-w-3xl max-h-[90vh] overflow-y-auto">
            <div className="h-64 overflow-hidden">
              <img 
                src={activeProject.image} 
                alt={activeProject.title} 
                className="w-full h-full object-cover"
              />
            </div>
            <div className="p-6">
              <h3 className="text-2xl font-bold text-gray-800 mb-4">{activeProject.title}</h3>
              <p className="text-gray-700 mb-6">{activeProject.description}</p>
              
              <h4 className="text-lg font-semibold text-gray-800 mb-2">Technologies Used:</h4>
              <div className="flex flex-wrap gap-2 mb-6">
                {activeProject.tech.map((tech, index) => (
                  <span key={index} className="px-3 py-1 text-sm font-medium bg-blue-100 text-blue-700 rounded-full">
                    {tech}
                  </span>
                ))}
              </div>
              
              <div className="flex justify-between mt-6">
                <a
                  href={activeProject.githubLink}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg transition-colors"
                >
                  View on GitHub
                  <Github size={20} className="ml-2" />
                </a>
                <button
                  onClick={closeProjectDetails}
                  className="px-4 py-2 bg-gray-200 hover:bg-gray-300 text-gray-800 font-medium rounded-lg transition-colors"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};

export default Projects;