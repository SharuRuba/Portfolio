export interface Project {
  id: number;
  title: string;
  description: string;
  tech: string[];
  githubLink: string;
  image: string;
}

export interface Skill {
  category: string;
  skills: {
    name: string;
    level: number;
  }[];
}

export interface Certification {
  title: string;
  issuer: string;
  description: string;
  icon: 'award' | 'check';
}